import axios from "axios"
import memoize from "lodash/memoize"

export const usdFormatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',

  // These options are needed to round to whole numbers if that's what you want.
  //minimumFractionDigits: 0, // (this suffices for whole numbers, but will print 2500.10 as $2,500.1)
  //maximumFractionDigits: 0, // (causes 2500.99 to be printed as $2,501)
});

export const usdFormatterWhole = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',

  // These options are needed to round to whole numbers if that's what you want.
  //minimumFractionDigits: 0, // (this suffices for whole numbers, but will print 2500.10 as $2,500.1)
  maximumFractionDigits: 0, // (causes 2500.99 to be printed as $2,501)
});

export const numberWithCommas = (x: String) =>
  x.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + "0"

export const getRandomData = (x: number) => {
  let old_price = x

  return [...Array(2000)].map((_, i) => {
    const rnd = Math.random(); // generate number, 0 <= x < 1.0
    const volatility = .02
    let change_percent = 2 * volatility * rnd;
    if (change_percent > volatility)
      change_percent -= (2 * volatility);
    const change_amount = old_price * change_percent;
    const new_price = old_price + change_amount;
    old_price = new_price
    return { argument: i, value: new_price }
  })
}

export const fetchSecData = memoize(async (ticker, assetClass) => {
  if (assetClass === "Crypto Currency") {
    const { data } = await axios.get(`https://www.alphavantage.co/query?function=DIGITAL_CURRENCY_DAILY&symbol=${ticker.split("/")[0]}&market=USD&apikey=AUHQHKPUTP0R3EK9`)
    if (!data || !data["Time Series (Digital Currency Daily)"]) return []
    // @ts-ignore
    return Object.entries(data["Time Series (Digital Currency Daily)"]).reverse().map(([k, v], i) => ({argument: i, value: parseFloat(v["4b. close (USD)"])}))
  }

  const { data } = await axios.get(`https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${ticker.split(".")[0]}&market=USD&apikey=AUHQHKPUTP0R3EK9`)
  if (!data || !data["Time Series (Daily)"]) return []
  // @ts-ignore
  return Object.entries(data["Time Series (Daily)"]).reverse().map(([k, v], i) => ({argument: i, value: parseFloat(v["4. close"])}))
})
