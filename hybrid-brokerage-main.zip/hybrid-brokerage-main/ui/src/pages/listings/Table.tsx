import React, { useState } from "react";
import { useStreamQueries } from "@daml/react";
import { Listing } from "@daml.js/brokerage-0.0.1/lib/Listing"
import Table from "@material-ui/core/Table";
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import TableBody from "@material-ui/core/TableBody";
import Button from "@material-ui/core/Button";
import { usdFormatter } from "utils";
import useStyles from "./styles";

export interface ListingsTableProps<T extends {[key: string]: any }> {
  selectedListingTicker: string | undefined
  onRowClick : (listing: Listing) => void
  onTradeClick : (listing: Listing) => () => void
}

export default function ListingsTable<T extends { [key : string] : any }>(props : ListingsTableProps<T>)  {
  const classes = useStyles();
  const listings = useStreamQueries(Listing).contracts

  return (
    <Table size="small">
      <TableBody>
        {listings.map(c => (
          <TableRow key={c.contractId} className={classes.tableRow} onClick={() => props.onRowClick(c.payload)} hover selected={props.selectedListingTicker === c.payload.security.ticker}>
            <TableCell key={0} className={classes.tableCell}>{c.payload.security.ticker}</TableCell>
            <TableCell key={1} className={classes.tableCell} align="right">{usdFormatter.format(parseFloat(c.payload.lastPrice))}</TableCell>
            <TableCell key={2} className={classes.tableCell}>{c.payload.security.sector}</TableCell>
            <TableCell key={3} className={classes.tableCell}>{c.payload.security.description}</TableCell>
            <TableCell key={5} className={classes.tableCell}><Button variant="outlined" onClick={props.onTradeClick(c.payload)}>Trade</Button></TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}
