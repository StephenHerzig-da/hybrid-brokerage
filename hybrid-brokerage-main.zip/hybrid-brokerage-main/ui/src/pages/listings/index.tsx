import React, { useEffect, useState } from "react";
import Ledger from "@daml/ledger";
import DamlLedger, { useStreamQueries, useLedger, useParty } from "@daml/react";
import { Investor } from "@daml.js/brokerage-0.0.1/lib/UserAdmin";
import { Portfolio } from "@daml.js/brokerage-0.0.1/lib/Portfolio";
import { Listing } from "@daml.js/brokerage-0.0.1/lib/Listing"
import {
  ArgumentAxis,
  ValueAxis,
  Chart,
  LineSeries,
  Title
} from '@devexpress/dx-react-chart-material-ui';
import { Box, CircularProgress, Typography } from "@material-ui/core";
import { wsBaseUrl, httpBaseUrl } from "config";
import { useUserState } from "context/UserContext";
import { TradeDialog } from "components/TradeDialog";
import ListingsTable from "./Table";
import { fetchSecData, usdFormatter } from "utils";
import useStyles from "./styles";

export default function Listings() {
  const classes = useStyles();
  const user = useUserState();
  const party = useParty();
  const ledger : Ledger = useLedger();
  const investors = useStreamQueries(Investor).contracts;
  const thisInvestor = investors.find(i => i.payload.investor === party)
  const portfolios = useStreamQueries(Portfolio).contracts
  const portfolioNames = portfolios.map(p => p.payload.name)

  const [tradeDialogOpen, setTradeDialogOpen] = useState(false)
  const closeTradeDialog = () => setTradeDialogOpen(false)

  const [selectedListing, setSelectedListing] = useState<Listing | null>(null)
  const onTradeClick = (listing: Listing) => () => {
    setSelectedListing(listing)
    setTradeDialogOpen(true)
  }
  const [data, setData] = useState<{ argument: number, value: any}[]>([])
  useEffect(() => {
    async function fetchData() {
      if (!selectedListing) {
        setData(await fetchSecData("BTC/USD", "Crypto Currency"))
        return
      }
      setData(await fetchSecData(selectedListing.security.ticker, selectedListing.security.assetClass))
    }
    fetchData()
  }, [selectedListing])

  const submitOrderRequest = async (portfolioIdx: number, listing: Listing, shares: number, limit?: number) => {
    if (!thisInvestor) return

    const portfolio = portfolios[portfolioIdx]
    const now = new Date()
    const start = now.toJSON()
    now.setHours(17)
    const end = now.toJSON()

    if (!limit)
      await ledger.exercise(Investor.RequestOrder, thisInvestor.contractId, {
        portfolio: portfolio.payload.name,
        ticker: listing.security.ticker,
        parameters: {tag: "Market", value: {buySell: "Buy", start, stop: end}},
        minQuantity: shares.toString(),
        maxQuantity: shares.toString()
      })
    else
      await ledger.exercise(Investor.RequestOrder, thisInvestor.contractId, {
        portfolio: portfolio.payload.name,
        ticker: listing.security.ticker,
        parameters: {tag:"Limit", value: {buySell: "Buy", start, stop: end, price: limit.toString()}},
        minQuantity: shares.toString(),
        maxQuantity: shares.toString()
      })

    setTradeDialogOpen(false)
  }

  /* TODO
  // 1. wire up buy/sell (add portfolio)
  // 2. wire up listing to line graph
  */

  if (!user.isAuthenticated) return null

  return (
    <Box>
      {/*
      // @ts-ignore */}
      {!!data.length ? <Chart className={classes.chart} height={200} width={600} data={data}>
        <ArgumentAxis showLabels={false} showTicks={false} />
        <ValueAxis showGrid={false} showLabels={false} />
        <LineSeries valueField="value" argumentField="argument" />
        <Title
          /* @ts-ignore */
          className={classes.chartTitle}
          text={selectedListing ? selectedListing.security.ticker : "BTC/USD"}
          textComponent={props =>
            <>
              <Title.Text {...props} style={{textAlign: "left", marginBottom: 0}} />
              <Typography variant="subtitle1" display="block">{usdFormatter.format(data.at(-1)?.value)}</Typography>
            </>
          }
        />
      </Chart> : <CircularProgress />}
      <Box mt={5}>
        <Typography className={classes.bold} variant="h3">Securities</Typography>
        <DamlLedger party="Public" token={user.publicToken} httpBaseUrl={httpBaseUrl} wsBaseUrl={wsBaseUrl}>
          <ListingsTable selectedListingTicker={selectedListing?.security.ticker} onRowClick={setSelectedListing} onTradeClick={onTradeClick} />
        </DamlLedger>
      </Box>
      {selectedListing &&
        <TradeDialog
          title="Trade"
          listing={selectedListing}
          portfolioNames={portfolioNames}
          open={tradeDialogOpen}
          onClose={closeTradeDialog}
          placeOrder={submitOrderRequest}
          isBuy
        />
      }
    </Box>
  );
}
