import React, { useState } from "react";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import Button from "@material-ui/core/Button";
import Ledger from "@daml/ledger";
import { useStreamQueries, useLedger, useParty } from "@daml/react";
import { Investor } from "@daml.js/brokerage-0.0.1/lib/UserAdmin";
import { LockedLot, Lot, Portfolio, Position } from "@daml.js/brokerage-0.0.1/lib/Portfolio";
import {
  ArgumentAxis,
  ValueAxis,
  Chart,
  LineSeries,
} from '@devexpress/dx-react-chart-material-ui';
import { AppBar, Box, Tab, Tabs, Typography } from "@material-ui/core";
import AccountBalanceIcon from "@material-ui/icons/AccountBalance"
import { getRandomData, usdFormatter } from "utils";
import { TradeDialog } from "components/TradeDialog";
import CollapseRow from "components/CollapseRow";
import useStyles from "./styles";
import { Listing } from "@daml.js/brokerage-0.0.1/lib/Listing";

interface IDictionary<TValue> {
  [key: string]: TValue;
}
const data: IDictionary<{ argument: number; value: number; }[]> = {
  Overall: getRandomData(100),
  Hybrid: getRandomData(100),
  Crypto: getRandomData(100),
  Equities: getRandomData(100)
}

export default function PortfolioPage() {
  const classes = useStyles();
  const party = useParty();
  const ledger : Ledger = useLedger();
  const investors = useStreamQueries(Investor).contracts;
  const thisInvestor = investors.find(i => i.payload.investor === party)
  const portfolios = useStreamQueries(Portfolio).contracts
  const portfolioNames = portfolios.map(p => p.payload.name)
  const positions = useStreamQueries(Position).contracts
  const lots = useStreamQueries(Lot).contracts
  const lockedLots = useStreamQueries(LockedLot).contracts
  const listings = useStreamQueries(Listing).contracts

  const [portfolioName, setPortoflio] = useState("Overall")
  const [position, setPosition] = useState<Position | null>(null)
  const listing = position ? listings.find(l => l.payload.security.ticker === position.ticker) : null
  const [tradeDialogOpen, setTradeDialogOpen] = useState(false)
  const portfolioNamesOverall = ["Overall"].concat(portfolioNames)

  const onSellClick = (p: Position) => () => {
    setPosition(p)
    setPortoflio(p.portfolio)
    setTradeDialogOpen(true)
  }

  const submitOrderRequest = async (portfolioIdx: number, listing: Listing, shares: number, limit?: number) => {
    if (!thisInvestor) return

    const portfolio = portfolios.find(p => p.payload.name === portfolioName)
    if (!portfolio) return

    const now = new Date()
    const start = now.toJSON()
    now.setHours(17)
    const end = now.toJSON()

    if (!limit)
      await ledger.exercise(Investor.RequestOrder, thisInvestor.contractId, {
        portfolio: portfolio.payload.name,
        ticker: listing.security.ticker,
        parameters: {tag: "Market", value: {buySell: "Sell", start, stop: end}},
        minQuantity: shares.toString(),
        maxQuantity: shares.toString()
      })
    else
      await ledger.exercise(Investor.RequestOrder, thisInvestor.contractId, {
        portfolio: portfolio.payload.name,
        ticker: listing.security.ticker,
        parameters: {tag:"Limit", value: {buySell: "Sell", start, stop: end, price: limit.toString()}},
        minQuantity: shares.toString(),
        maxQuantity: shares.toString()
      })

    setTradeDialogOpen(false)
  }

  const filteredPositions = portfolioName === "Overall" ? positions : positions.filter(p => p.payload.portfolio === portfolioName)
  const cost = filteredPositions.reduce<number>((cost, p) => cost += parseFloat(p.payload.cost), 0)
  const starting = portfolioName === "Overall" ? 6000000 : 2000000
  const diff = starting - cost
  const perc = ((diff / starting) * 100).toFixed(2)
  const sign = diff > 0 ? "-" : "+"

  // TODO:
  // 1. wire up bank deposit/withdraw
  // 2. wire up sell

  return (
    <Box>
      <AppBar position="static" color="default">
        <Tabs value={portfolioName} onChange={(e, newVal) => setPortoflio(newVal)} indicatorColor="primary" textColor="primary" centered>
          {portfolioNamesOverall.map(n => <Tab key={n} label={n} value={n} />)}
        </Tabs>
      </AppBar>
      <Box mt={5} display="flex">
        <div>
          <Button endIcon={<AccountBalanceIcon color="primary" />}>
            <Typography className={classes.bold} variant="h2" color="textPrimary">{usdFormatter.format(cost)}</Typography>
          </Button>
          <Typography gutterBottom><b>{sign}${diff} ({sign}{perc}%)</b> Today</Typography>
        </div>
      </Box>
      <Chart height={200} width={600} data={data[portfolioName]}>
        <ArgumentAxis showLabels={false} showTicks={false} />
        <ValueAxis showGrid={false} showLabels={false} />
        <LineSeries valueField="value" argumentField="argument" />
      </Chart>
      <Box mt={5}>
        <Typography className={classes.bold} variant="h3">Positions</Typography>
        <Table size="small">
          <TableBody>
            {filteredPositions.map(p => {
              const filteredLots = lots.filter(l =>
                l.payload.portfolio === p.payload.portfolio && p.payload.lots.includes(l.payload.entry.id))
              const filteredLockedLots = lockedLots.filter(l =>
                l.payload.portfolio === p.payload.portfolio && p.payload.ticker === l.payload.ticker)

              return (
                <CollapseRow position={p} lots={filteredLots} lockedLots={filteredLockedLots} onSellClick={onSellClick(p.payload)} portfolio={portfolioName} />
              )
            })}
          </TableBody>
        </Table>
      </Box>
      {listing && position &&
        <TradeDialog
          listing={listing.payload}
          position={position}
          portfolioNames={[portfolioName]}
          title="Trade"
          open={tradeDialogOpen}
          onClose={() => setTradeDialogOpen(false)}
          placeOrder={submitOrderRequest}
        />
      }
    </Box>
  );
}
