import React, { useState } from "react";
import Table from "@material-ui/core/Table";
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import TableBody from "@material-ui/core/TableBody";
import { useStreamQueries, useLedger, useParty } from "@daml/react";
import { PendingOrder } from "@daml.js/brokerage-0.0.1/lib/Order"
import { Box, TableHead, Typography } from "@material-ui/core";
import { numberWithCommas, usdFormatter } from "utils";
import useStyles from "./styles";

export default function Orders() {
  const classes = useStyles();
  const orders = useStreamQueries(PendingOrder).contracts

  return (
    <Box>
      <Typography className={classes.bold} variant="h3">Open Orders</Typography>
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell key={0} className={classes.tableCell}>Ticker</TableCell>
            <TableCell key={1} className={classes.tableCell}>Time Placed</TableCell>
            <TableCell key={2} className={classes.tableCell}>Portfolio</TableCell>
            <TableCell key={3} className={classes.tableCell}>Type</TableCell>
            <TableCell key={4} className={classes.tableCell}>Quantity</TableCell>
            <TableCell key={5} className={classes.tableCell}>Limit</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {orders.map(c => (
            <TableRow key={c.contractId} className={classes.tableRow}>
              <TableCell key={0} className={classes.tableCell}>{c.payload.ticker}</TableCell>
              <TableCell key={1} className={classes.tableCell}>{new Date(c.payload.placed).toLocaleString()}</TableCell>
              <TableCell key={2} className={classes.tableCell}>{c.payload.portfolio}</TableCell>
              <TableCell key={3} className={classes.tableCell}>{c.payload.parameters.tag} {c.payload.parameters.value.buySell}</TableCell>
              <TableCell key={4} className={classes.tableCell} align="right">{numberWithCommas(c.payload.minQuantity)}</TableCell>
              <TableCell key={5} className={classes.tableCell} align="right">
                {c.payload.parameters.tag === "Limit" ? usdFormatter.format(parseFloat(c.payload.parameters.value.price)) : "N/A"}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Box>
  );
}
