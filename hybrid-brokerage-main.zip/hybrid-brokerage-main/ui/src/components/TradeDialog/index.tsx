import React, { useState } from "react";
import Dialog from "@material-ui/core/Dialog";
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogContent from "@material-ui/core/DialogContent";
import DialogActions from "@material-ui/core/DialogActions";
import Button from "@material-ui/core/Button";
import Select from '@material-ui/core/Select';
import TextField from "@material-ui/core/TextField";
import Divider from "@material-ui/core/Divider";
import Typography from "@material-ui/core/Typography";
import MenuItem from "@material-ui/core/MenuItem";
import InputAdornment from "@material-ui/core/InputAdornment";
import { Listing } from "@daml.js/brokerage-0.0.1/lib/Listing";
import { Position } from "@daml.js/brokerage-0.0.1/lib/Portfolio";
import { Box, InputLabel } from "@material-ui/core";
import { numberWithCommas, usdFormatter } from "utils";
import useStyles from "./styles";

export interface TradeDialogProps<T extends {[key: string]: any }> {
  open: boolean
  title: string
  listing: Listing
  position?: Position
  portfolioNames: string[]
  isBuy?: boolean
  onClose : () => void
  placeOrder: (portfolioIdx: number, listing: Listing, shares: number, limit?: number) => void
}

export function TradeDialog<T extends { [key : string] : any }>(props : TradeDialogProps<T>) {
  const classes = useStyles();
  const [isBuy, setIsBuy] = useState(props.isBuy && true)
  const [isLimit, setIsLimit] = useState(0)
  const [shares, setShares] = useState(0)
  const price = parseFloat(props.listing.lastPrice)
  const [limit, setLimit] = useState(price)
  const [portfolioIdx, setPortfolioIdx] = useState(0)

  return (
    <Dialog open={props.open} onClose={() => props.onClose()} maxWidth="xs" fullWidth>
      <DialogTitle>
        <Button className={classes.buySellButton} variant={isBuy ? "outlined" : "text"} onClick={() => setIsBuy(true)}>Buy</Button>
        <Button className={classes.buySellButton} variant={!isBuy ? "outlined" : "text"} onClick={() => setIsBuy(false)}>Sell</Button>
        <Select className={classes.marketLimitSelect} value={isLimit} onChange={(event) => setIsLimit(event.target.value as number)}>
          <MenuItem value={0}>Market</MenuItem>
          <MenuItem value={1}>Limit</MenuItem>
        </Select>
      </DialogTitle>
      <Divider />
      <DialogContent>
        <Typography variant="h3">{props.listing.security.ticker}</Typography>
        {props.position && <Typography variant="subtitle2" gutterBottom>{numberWithCommas(props.position.quantity)} {props.listing.security.countNoun} available</Typography>}
        <Box mt={5}>
          <InputLabel>Portfolio: </InputLabel>
          {props.portfolioNames.map((pn, i) =>
            <Button key={pn} classes={{disabled: classes.disabledButton}} value={i} variant={i === portfolioIdx ? "outlined" : "text"} onClick={() => setPortfolioIdx(i)} disabled={props.portfolioNames.length === 1}>
              {pn}
            </Button>
          )}
        </Box>
        <div>
          {!!isLimit &&
            <TextField
              margin="normal"
              label="Limit Price"
              type="number"
              InputProps={{startAdornment: <InputAdornment position="start">$</InputAdornment>}}
              value={limit}
              onChange={(e) => setLimit(parseFloat(e.target.value))}
            />
          }
        </div>
        <div>
          <TextField
            margin="normal"
            label={props.listing.security.countNoun}
            type="number"
            value={shares}
            onChange={(e) => setShares(parseFloat(e.target.value))}
            InputProps={{ inputProps: { min:0 } }}
          />
        </div>
        <Typography className={classes.price}>Market Price: {usdFormatter.format(price)}</Typography>
        <Divider className={classes.divider} />
        <Typography className={classes.bold}>Estimated {isBuy ? "Cost" : "Credit"}: {usdFormatter.format(shares*(isLimit ? limit : price))}</Typography>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => props.onClose()}>
          Cancel
        </Button>
        <Button variant="contained" onClick={() => props.placeOrder(portfolioIdx, props.listing, shares, (isLimit ? limit : undefined))} color="primary">
          Place Order
        </Button>
      </DialogActions>
    </Dialog>
  );
}
