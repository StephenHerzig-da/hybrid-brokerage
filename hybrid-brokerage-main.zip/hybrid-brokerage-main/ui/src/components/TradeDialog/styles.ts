import { makeStyles, createStyles } from "@material-ui/styles";

export default makeStyles((theme : any) => createStyles({
  buySellButton: {
    fontWeight: 600,
  },
  marketLimitSelect: {
    float: "right",
  },
  price: {
    marginTop: 15
  },
  divider: {
    margin: "15px 0 15px 0"
  },
  bold: {
    fontWeight: 600
  },
  disabledButton: {
    color: "#4A4A4A!important"
  }
}));
