import React from "react";

interface TabPanelProps<T extends {[key: string]: any }> {
  children: object
  value: any
  index: any
}

export default function TabPanel<T extends { [key : string] : any }>(props: TabPanelProps<T>) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`wrapped-tabpanel-${index}`}
      aria-labelledby={`wrapped-tab-${index}`}
      {...other}
    >
      {value === index && children}
    </div>
  );
}
