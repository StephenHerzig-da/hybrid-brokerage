import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Box from '@material-ui/core/Box';
import Collapse from '@material-ui/core/Collapse';
import IconButton from '@material-ui/core/IconButton';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import Lock from '@material-ui/icons/Lock'
import Button from '@material-ui/core/Button';
import { CreateEvent } from '@daml/ledger';
import { LockedLot, Lot, Position } from '@daml.js/brokerage-0.0.1/lib/Portfolio';
import { numberWithCommas, usdFormatterWhole } from 'utils';
import useStyles from "./styles";

export interface RowProps<T extends {[key: string]: any }> {
  position: CreateEvent<Position>
  lots: CreateEvent<Lot>[]
  lockedLots: CreateEvent<LockedLot>[]
  onSellClick: () => void
  portfolio: string
}

export default function Row<T extends { [key : string] : any }>(props : RowProps<T>)  {
  const classes = useStyles();
  const { position, lots, lockedLots } = props;
  const [open, setOpen] = React.useState(false);
  const lockedLotsAmount = lockedLots.reduce((amt, l) => amt + parseFloat(l.payload.entry.quantity), 0.0)
  const costWithLocked = parseFloat(position.payload.cost) + lockedLotsAmount
  const quantityWithLocked = (parseFloat(position.payload.quantity) + lockedLotsAmount).toFixed(1).toString()

  return (
    <>
      <TableRow key={position.contractId} className={classes.tableRow}>
        <TableCell key={0} className={classes.tableCell}>{position.payload.ticker}</TableCell>
        <TableCell key={1} className={classes.tableCell} align="right">{usdFormatterWhole.format(costWithLocked)}</TableCell>
        <TableCell key={2} className={classes.tableCell} align="right">{numberWithCommas(quantityWithLocked)}</TableCell>
        {props.portfolio === "Overall" &&
          <TableCell key={3} className={classes.tableCell}>{props.position.payload.portfolio}</TableCell>
        }
        <TableCell key={4} className={classes.tableCell}>
          <Button variant="outlined" onClick={props.onSellClick} disabled={props.position.payload.ticker === "USD"}>
            Sell
          </Button>
        </TableCell>
        <TableCell key={5} className={classes.tableCell}>
          <IconButton aria-label="expand row" size="small" onClick={() => setOpen(!open)}>
            {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
      </TableRow>
      <TableRow>
        <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
          <Collapse in={open} timeout="auto" unmountOnExit>
            <Box margin={1}>
              <Typography variant="h6" gutterBottom component="div">
                Lots
              </Typography>
              <Table size="small" aria-label="purchases">
                <TableBody>
                {lots.map(l =>
                  <TableRow key={l.contractId} className={classes.tableRow}>
                    <TableCell key={0} className={classes.tableCell} style={{color: l.payload.entry.id.includes("Fee") ? "red" : ""}}>
                      {l.payload.entry.id}
                    </TableCell>
                    <TableCell key={1} className={classes.tableCell}>{new Date(l.payload.created).toLocaleString()}</TableCell>
                    <TableCell key={2} className={classes.tableCell} align="right">{usdFormatterWhole.format(parseFloat(l.payload.entry.price))}</TableCell>
                    <TableCell key={3} className={classes.tableCell} align="right">{numberWithCommas(l.payload.entry.quantity)}</TableCell>
                    <TableCell key={4} className={classes.tableCell} style={{color: l.payload.entry.id.includes("Fee") ? "red" : ""}} align="right">
                      {usdFormatterWhole.format(parseFloat(l.payload.entry.price) * parseFloat(l.payload.entry.quantity))}
                    </TableCell>
                  </TableRow>
                )}
                {lockedLots.map(l =>
                  <TableRow key={l.contractId} className={classes.tableRow}>
                    <TableCell key={0} className={classes.tableCell} style={{color: l.payload.entry.id.includes("Fee") ? "red" : ""}}>
                      <Lock fontSize="small" />{l.payload.entry.id}
                    </TableCell>
                    <TableCell key={1} className={classes.tableCell}>{new Date(l.payload.created).toLocaleString()}</TableCell>
                    <TableCell key={2} className={classes.tableCell} align="right">{usdFormatterWhole.format(parseFloat(l.payload.entry.price))}</TableCell>
                    <TableCell key={3} className={classes.tableCell} align="right">{numberWithCommas(parseFloat(l.payload.entry.quantity).toFixed(1))}</TableCell>
                    <TableCell key={4} className={classes.tableCell} style={{color: l.payload.entry.id.includes("Fee") ? "red" : ""}} align="right">
                      {usdFormatterWhole.format(parseFloat(l.payload.entry.price) * parseFloat(l.payload.entry.quantity))}
                    </TableCell>
                  </TableRow>
                )}
                </TableBody>
              </Table>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </>
  );
}