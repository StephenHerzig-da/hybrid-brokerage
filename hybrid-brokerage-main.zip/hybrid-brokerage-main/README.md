# hybrid-brokerage

A client-portal for a hybrid-brokerage.

## Workflow 

![Workflow](brokerage/brokerage.png)

## Making

```sh 
make clean && make build
```

...will rebuild everything.

## Running

Run the following in different terminals:

### 1. Start the sandbox

```sh 
cd setup && daml start
```

### 2. UI

```sh 
cd ui && yarn start 
```

### 3. Auto-check trigger

```sh 
cd triggers
daml trigger --dar .daml/dist/triggers-0.0.1.dar --trigger-name Broker:autoCheck --ledger-host localhost --ledger-port 6865 --ledger-party "Broker"
```
This supplies an id to each order. Otherwise, log in as the Broker to validated each Order.

### 4. Auto-execute trigger

```sh 
cd triggers
daml trigger --dar .daml/dist/triggers-0.0.1.dar --trigger-name Broker:autoExecute --ledger-host localhost --ledger-port 6865 --ledger-party "Broker"
```
This will DvP filled orders with the reserved cash payment.